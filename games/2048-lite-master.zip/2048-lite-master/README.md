# 2048-lite

Lite version of 2048 clone

<https://github.com/attogram/2048-lite>
